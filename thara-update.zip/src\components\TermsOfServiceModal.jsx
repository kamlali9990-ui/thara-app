import { memo, useEffect } from 'react';
const BASE = import.meta.env.BASE_URL || '/';

const TermsOfServiceModal = memo(({ isOpen, onClose }) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="terms-overlay" onClick={onClose}>
      <div className="terms-modal" onClick={(e) => e.stopPropagation()}>
        <button className="terms-close" onClick={onClose}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
        <h2 className="terms-title">اتفاقية استخدام أسواق ثراء الشرق ون</h2>
        <div className="terms-content">
          <p>باستخدامك لتطبيقنا، فإنك توافق على البنود التالية:</p>
          <h3>١. الصور والمنتجات</h3>
          <p>قد تختلف الصورة المعروضة عن المنتج الفعلي أحيانًا، وهذا أمر خارج عن إرادتنا. نبذل قصارى جهدنا لتوفير صور دقيقة، ولكن قد يحدث اختلاف في اللون أو الشكل أو التغليف بسبب التحديثات من الموردين.</p>
          <h3>٢. تحديث الأصناف تلقائيًا</h3>
          <p>قد يتم تحديث الأصناف والمنتجات المتاحة تلقائيًا بناءً على توفر المخزون والتحديثات من الموردين. نحن غير مسؤولين عن أي تغيير مفاجئ في توفر المنتجات.</p>
          <h3>٣. الالتزام بالدعم وسياسة الإرجاع</h3>
          <p>نحن ملتزمون بتقديم أفضل دعم لعملائنا، وفي حال وجود أي خطأ في الطلب أو المنتج، نضمن لك سياسة إرجاع مرنة. يرجى التواصل معنا عبر واتساب أو الاتصال المباشر لحل أي مشكلة.</p>
          <h3>٤. الاستخدام الآمن والخصوصية</h3>
          <p>نلتزم بالاستخدام الآمن تمامًا. لا يتطلب موقعنا أي أذونات وصول لأجهزة المستخدمين الكرام سوى الإشعارات للتنبيه على الوصول والعروض، والموقع لتحديد المنطقة بدقة لإيصال الطلبات. لا نتبع سياسة الوصول للصور أو الكاميرات أو الملفات أو أي بيانات شخصية. نحن نلتزم قانونيًا بهذا، وهدفنا تقديم خدمة اجتماعية آمنة ومختلفة عن سياسات التطبيقات الأخرى.</p>
          <p>يعمل متجرنا بتقنية ويب آب (PWA) القابلة للعمل على كافة الأجهزة والأنظمة: الجوال، الكمبيوتر، والجهاز المحمول، دون الحاجة إلى تثبيت تطبيق من المتاجر.</p>
          <h3>٥. التوصيل والدفع</h3>
          <p>خدمة التوصيل متاحة داخل مدينة الخفجي وفروعها. يتم تأكيد الطلب بعد التواصل مع العميل. جميع المدفوعات تتم بشكل آمن، ونحن ملتزمون بحماية بياناتك.</p>
          <h3>٦. التعديل على الاتفاقية</h3>
          <p>نحتفظ بالحق في تعديل هذه الاتفاقية في أي وقت. سيتم إشعار المستخدمين بأي تغييرات جوهرية عبر التطبيق.</p>
          <div className="terms-download-app">
            <a href={`${BASE}thara-app.apk`} download className="terms-download-link" target="_self">
              📲 تحميل تطبيق أندرويد
            </a>
          </div>
          <div className="terms-footer-text">
            <p>إذا كان لديك أي استفسار، تواصل معنا عبر واتساب: <strong dir="ltr">0503074260</strong></p>
          </div>
        </div>
      </div>
    </div>
  );
});

export default TermsOfServiceModal;
